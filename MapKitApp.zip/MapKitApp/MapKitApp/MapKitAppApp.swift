//
//  MapKitAppApp.swift
//  MapKitApp
//
//  Created by Wendy Sanchez Cortes on 11/04/24.
//

import SwiftUI

@main
struct MapKitAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
